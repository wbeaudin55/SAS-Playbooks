#ifndef vgp_ext_h_included
#define vgp_ext_h_included

/**
 * Quest Authentication Services Group Policy (QAS GP)
 * Client-Side Extension API 
 *
 * Copyright (c) 2010 Quest Software, Inc. All Rights Reserved.
 *
 * The C interface called by vgptool on client-side group policy
 * extensions (CSEs). vgptool dynamically loads and calls 
 * registered CSEs.
 *
 * The function descriptions contain some information 
 * implementation, but to avoid errors, please contact Support 
 * at Quest Software. 
 *  
 * All of the interfaces with the exception of 
 * vgp_get_gpt_info() must be implemented for any new 
 * client-side extension.  Some may be implemented to just to 
 * return zero, except for vgp_get_extension_guids() which has 
 * out parameters that must be initialized.  Failing to 
 * initialize these values could cause a segmentation fault in 
 * vgptool. 
 *
 **/

/*===========================================================================
 * 
 * 
 *===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

/** QAS GP Client-side Extension Calltypes
 * 
 *  Defines the conditions under which the CSE is being called.
 *  These conditions may affect the behavior of the CSE.
 *  
*/

/**
 * Called for standard policy refresh loop
 */
#define VGPEXT_CT_STANDARD_REFRESH  0

/**
 * Called when vasd first starts
 */
#define VGPEXT_CT_SYSTEM_STARTUP    10

/**
 * Called when a user logs on
 */
#define VGPEXT_CT_USER_LOGON        20

/**
 * Called after license policy has been applied
 */
#define VGPEXT_CT_AFTER_LICENSE     91

/**
 *  Called to un-apply policy
 */
#define VGPEXT_CT_UNAPPLY           99

/**
 * Called to obtain version information
 */
#define VGPEXT_VERSION    4

/**
 *  Called to un-apply without flushing the cache
 */
#define VGPEXT_CT_UNJOIN            95

/* Forward declaration of the standard passwd struct */
struct passwd;

/* QAS Authentication Context */
typedef struct vas_ctx vas_ctx_t;
typedef struct vas_id vas_id_t;
typedef struct
{
    int version;
    union
    {
        struct
        {
            vas_ctx_t* vasctx;
            vas_id_t*  vasid;
        }
        version4;
    }
    data;
} vgp_auth_t;

/**
 * This interface is used by vgptool to register the CSE 
 * to be called during policy processing.  The vgptool register command uses
 * this interface to get the GUIDs that identify a CSE in
 * Active Directory (the MachineExtensionNames and UserExtensionNames
 * properties).  All of the parameters to this function are out parameters
 * that will be used by vgptool later.
 * <P>
 * Example Code:
 * -------------
 *     *ptype_guids = (char**)malloc(2*sizeof(char*));
 *
 *     (*ptype_guids)[0] = strdup("088D15C8-3F55-4174-B3D4-AE8706CC1762");
 *     (*ptype_guids)[1] = NULL;
 *
 *     *cse_guid = "A53C278E-317C-422E-83FB-323F03CA5F48";
 *     *version = VGPEXT_VERSION;
 *
 *     return 0;
 * <P>
 * @param  cse_guid  A hard coded character array that represents the GUID of
 *                   this extension.  vgptool will NOT free this
 *                   memory.
 * @param  ptype_guids  A NULL terminated array of character arrays that
 *                      represent each of the policy types that
 *                      this CSE has been designed to process.
 *                      vgptool calls free() to release this
 *                      memory.
 * @param  version  The version number of the interface that this extension
 *                  supports.
 * @return  Non-zero error code or zero for success.  If an 
 *          error code is returned, a reference to this
 *          extension will not be placed in the registration
 *          file.
 */
int vgp_get_extension_guids( char** cse_guid,
                             char*** ptype_guids,
                             int* version );

/**
 * This function allows the CSE to perform any actions that 
 * should take place prior to policy application, such as 
 * support for enforced policies. This function would be the proper 
 * place to initialize a cache for supporting enforced policies.
 *  
 * <P> This interface will be called once by vgptool on each 
 * registered client-side extension before policy application. 
 * <P>
 * @param  auth      Authentication information from vgptool
 * @param  calltype  Integer value representing the QAS GP 
 *                   Calltype.
 *                   
 * @param  pwd       A pointer to a passwd struct if User Policy is being
 *                   applied.  If User Policy is not being applied the pointer
 *                   will be NULL.
 * @return  Non-zero error code or zero for success.
 */
int vgp_extension_init( const vgp_auth_t* auth,
                        const int calltype,
                        const struct passwd* pwd );

/**
 * vgptool assumes the role of determining which GPOs are applied to a client,
 * and also determines which GPOs contain information that a 
 * given CSE needs.  These GPOs are handed to the client-side 
 * extension one at a time so that the extension can determine 
 * what policy settings need to be applied based on the GPO. 
 * <P>
 * vgptool provides information about the GPO in the parameters
 * listed below.  It is the responsibility of the CSE to locate 
 * its settings in the GPT. These settings can be applied 
 * immediately, or the CSE can wait until it has accumulated all 
 * of the settings and it gets called on the vgp_apply_changes 
 * interface.  
 * <P>
 * @param  auth      Authentication information from vgptool
 * @param  ptype_guid  This a GUID that corresponds to a policy
 *                     type that this CSE can process.  The
 *                     extension is being called to execute functionality
 *                     specific to this GUID.
 * @param  gpo_name  The name of this GPO in Active Directory.
 * @param  gpc_dn  The DN to the Group Policy Container in Active Directory.
 * @param  gpo_link  The container in Active Directory to which the GPO was
 *                   linked.
 * @param  link_order  Link order assigned to the GPO on the container.
 * @param  sysvol_gpt_path  The path to the Group Policy Template on the
 *                          SysVol share of the domain controller.
 * @param  local_gpt_path  Local file location to which the GPT has been
 *                         downloaded.  Extensions should access
 *                         their data files from this location
 *                         if possible.
 * @param  calltype  Integer value representing how vgptool 
 *                   apply was called.
 *                   
 * @param  enforced  Whether the GPO should be enforced or not.
 * @param  pwd       A pointer to a passwd struct if User Policy is being
 *                   applied.  If User Policy is not being applied the pointer
 *                   will be NULL.
 * @return  An integer representing the error code or zero for success.
 */
int vgp_accumulate_settings( const vgp_auth_t* auth,
                             const char* ptype_guid,
                             const char* gpo_name,
                             const char* gpc_dn,
                             const char* gpo_link,
                             const int link_order,
                             const char* sysvol_gpt_path,
                             const char* local_gpt_path,
                             const int calltype,
                             const int enforced,
                             const struct passwd* pwd );
/**
 * This function will be called by vgptool once all of the policy settings
 * have been accumulated from the GPOs that are applied to the 
 * client.  During  the accumulation stage, GPTs will be 
 * provided in the correct hierarchical order and GPOs blocked 
 * by the block inheritance attribute will be filtered. Enforced
 * policy settings must be correctly resolved by the CSE. 
 *  
 * <P>Usually a CSE will make system changes in response to this
 * function call.  It is also a good idea to provide some type 
 * of output (to stdout) describing the changes for the benefit 
 * of an administrator running vgptool at the command prompt. 
 * <P> The CSE must keep a record of the changes made in order 
 * to correctly un-apply the settings and to support RSoP. 
 * <P>
 * @param  auth      Authentication information from vgptool
 * @param  calltype  Integer value representing how vgptool 
 *                   apply was called.
 * @param  pwd       A pointer to a passwd struct if User Policy is being
 *                   applied.  If User Policy is not being applied the pointer
 *                   will be NULL.
 * @return  An integer representing an error code or zero for success.
 */
int vgp_apply_changes( const vgp_auth_t* auth,
                       const int calltype,
                       const struct passwd* pwd );

/**
 * This function is called to request RSoP information from the 
 * CSE.  RSoP is reported for the settings that are currently 
 * applied to this client by this CSE. The extension is given a 
 * path to a file that should be created and filled with an XML 
 * 1.0 representation of the applied settings. 
 * <P>
 * The DTD for the XML file to be created the vgpext.h API: 
 *
 * <!DOCTYPE RSoPFile [
 *         <!ELEMENT RSoPFile(Version,(GPO)*)>
 *         <!ELEMENT Version(#PCDATA)>
 *         <!ELEMENT GPO(GPOName,GPOGuid,(CSE)*)>
 *         <!ELEMENT GPOName(#PCDATA)>
 *         <!ELEMENT GPOGuid(#PCDATA)>
 *         <!ELEMENT CSE(CSEName,(Setting)*)>
 *         <!ELEMENT CSEName(#PCDATA)>
 *         <!ELEMENT Setting(Name,Description,Value)>
 *         <!ELEMENT Name(#PCDATA)>
 *         <!ELEMENT Description(#PCDATA)>
 *         <!ELEMENT Value((row)*)>
 *         <!ELEMENT row((col)*)>
 *         <!ELEMENT col(#PCDATA)>
 * ]>
 *
 * <P>
 * @param  auth      Authentication information from vgptool
 * @param  rsop_file_path  This is the path where the RSoP XML file should be
 *                         created and written.
 * @param  pwd       A pointer to a passwd struct if User Policy reporting is
 *                   requested.  If Machine Policy reporting is requested
 *                   this pointer will be NULL.
 * @return  An integer representing the error code or zero for success.
 */
int vgp_get_rsop( const vgp_auth_t* auth,
                  const char* rsop_file_path,
                  const struct passwd* pwd );

/**
 * This function is called to display the information from the 
 * GPT that is used by the CSE.  This is used for 
 * troubleshooting and debugging.  To implement this function, 
 * simply print out the data from the policy settings file to 
 * the screen. Make sure to print only the information relevant 
 * to the extension identified by the guid parameter.  
 * <P>
 * @param  auth      Authentication information from vgptool
 * @param  ptype_guid  This is one of the GUIDs that corresponds to a policy
 *                     type that this client-side extension can process.  The
 *                     extension is being called to display the info used by
 *                     the functionality specific to this GUID.
 * @param  local_gpt_path  Local file location to which the GPT has been
 *                         downloaded.  The GPT should have a data file that
 *                         this extension cares about.
 * @param  verbose  0 is normal, all other values are verbose.
 * @param  pwd   A pointer to a passwd struct if User Policy settings are
 *               being listed.  If Machine Policy settings are being listed
 *               then the pointer will be NULL.
 * @return  An integer representing an error code or zero for success.
 */
int vgp_display_gpt_info( const vgp_auth_t* auth,
                          const char* ptype_guid,
                          const char* local_gpt_path,
                          const int verbose,
                          const struct passwd* pwd );

/** relative_path
 *       policy_name
 *           A common identifier by which your policy may be named --
 *           some examples from Vintela: sudo_sudoers, vas_conf, unix_file_copy.
 *       paths
 *           The locations of files that the CSE cares about within the GPT.
 *       order
 *           Specifies the order in which this policy will be processed by the
 *           CSE in relation to other policies.
*/
typedef struct relative_path
{
    char* policy_name;
    char** paths;
    unsigned int order;
} relative_path_t;
/** gpt_info
 *        ptype_name
 *           This is a common name that corresponds with the policy type GUID
 *           as it would be recorded in MachineExtensionNames or
 *           UserExtensionNames of the GPC -- many of the Vintela CSEs only have
 *           one policy type GUID for Machine and one for User (to be used in
 *           the future).
 *       ptype_guid
 *           This is the GUID value as would be recorded in
 *           MachineExtensionNames or UserExtensionNames of the GPC.
 *       relative_paths
 *           This contains information on where all of the information for
 *           different policies is stored within the GPT.
 */
typedef struct gpt_info
{
    char*              ptype_name;
    char*              ptype_guid;
    relative_path_t*   relative_paths;
} gpt_info_t;


/**
 * This interface has been created for use with vgpmod.  If you 
 * want your CSE to work with vgpmod, you must implement this 
 * interface, otherwise, this interface is optional. 
 *  
 * This function returns information about the settings data 
 * that is stored in the GPT for this CSE. The implementation 
 * should return an array of gpt_info_t arrays.  Refer to the 
 * example below for how these arrays should be allocated. 
 * 
 * <p>
 * This information may also include an entire directory in addition to
 * specific files.  This is denoted by a trailing slash followed
 * by a trailing *. 
 * <p>
 * Example Code:
 * -------------
 *   *gpt_infos = ( gpt_info_t* )malloc( 2 * sizeof( gpt_info_t ) );
 *
 *   ( *gpt_infos )[0].ptype_name = strdup( "Machine" );
 *   ( *gpt_infos )[0].ptype_guid = strdup( "23BE86A1-20EE-43D1-9AB1-C4588C4FE6E5" );
 *   ( *gpt_infos )[0].relative_paths = ( relative_path_t* )malloc( 2 * sizeof( relative_path_t ) );
 *
 *   ( *gpt_infos )[0].relative_paths[0].policy_name = strdup( "my_policy" );
 *   ( *gpt_infos )[0].relative_paths[0].order = 11;
 *   ( *gpt_infos )[0].relative_paths[0].paths = ( char** )malloc( 3 * sizeof( char* ) );
 *   ( *gpt_infos )[0].relative_paths[0].paths[0] = strdup( "VGP/MyCompany/MyCSEPath/manifest.xml" );
 *   ( *gpt_infos )[0].relative_paths[0].paths[1] = NULL;
 *
 *   ( *gpt_infos )[0].relative_paths[1].policy_name = NULL;
 *   ( *gpt_infos )[0].relative_paths[1].paths = NULL;
 *
 *   ( *gpt_infos )[1].ptype_guid = NULL;
 *   ( *gpt_infos )[1].relative_paths = NULL;
 *
 *   return 0;
 * <p>
 * @param  gpt_infos  Out parameter containing an array of gpt_info_t structures;
 *                    vgpmod will free() the allocated memory.
 * @return Always zero.
 */
int vgp_get_gpt_info( gpt_info_t** gpt_infos );

#ifdef __cplusplus
} // extern "C"
#endif

#endif

