#!/bin/sh

################################################################################
# Copyright 2021 One Identity LLC. ALL RIGHTS RESERVED.
#
# DESCRIPTION:
# This script will be called on all the platforms for signalling the appropriate
# daemons after their configuration files have been updated.  This will force
# the daemon to reread its configuration and exhibit any new functionality that
# may have been specified by VGP.
#
# SERVICES SUPPORTED:
#     syslog
#     sshd from One Identity Resource Central
################################################################################

################################################################################
#  DebugEcho
#    only echo if debug is turned on
################################################################################
DebugEcho()
{
    debuglvl=`env | grep VAS_LOG_DEBUG_LEVEL | cut -d"=" -f2`
    if [ ! -z "$debuglvl" ]; then
        if [ $debuglvl -gt 1 ]; then
            echo $1
        fi
    fi
}

################################################################################
# DeterminePlatform
#    it is necessary to know which platform we are on so that we can locate the
#    pid file, so that we know where to send the SIGHUP.
################################################################################
DeterminePlatform()
{
    name=`uname`
    case $name in
        "Linux")
            isubuntu=`cat /etc/*release 2>&1 | tr A-Z a-z | grep ubuntu`
            if [ -z "$isubuntu" ]; then
                platform="Linux"
            else
                platform="Ubuntu"
            fi
            ;;
        "SunOS")
            platform="Solaris"
            ;;
        "AIX")
            platform="AIX"
            ;;
        "HP-UX")
            platform="HPUX"
            ;;
        "Darwin")
            platform="DARWIN"
            ;;
        *)
            return 1
            ;;
    esac
    return 0 
}

################################################################################
# ReadPidFile
#    Read the pid from the specified file and return it.
################################################################################
ReadPidFile()
{
    if [ -z "$1" ]; then
        return 1
    fi
    if [ -f $1 ]; then
        pid=`cat $1`
        if [ $? != 0 ]; then
            return 1
        fi
    else
        echo "pid file doesn't exist: $1"
        return 1
    fi
    return 0
}


################################################################################
# SendSigHup
#    Send a SIGHUP to the specified pid using kill.
################################################################################
SendSigHup()
{
    if [ -z "$1" ]; then
        echo "Unable to determine pid, is $service running?"
        return 1
    fi
    DebugEcho "pid=$1"
    pidexist=`ps -p $1 | grep $1`
    DebugEcho "pidexist=$pidexist"
    if [ -z "$pidexist" ]; then
        echo "The service is not running, pid does not exist"
        return 1
    fi
    kill -HUP $1
    return $?
}


################################################################################
# This is where the main script body begins.
################################################################################

# validate parameter and determine platform
if [ -z $1 ]; then
    echo "You must specify the service that you would like to signal"
    exit 1
fi
service=$1
pidfile=$2
DeterminePlatform
if [ $? -eq 1 ]; then
    echo "Unable to determine platform information"
    exit 1
fi
DebugEcho "service=$service"
DebugEcho "platform=$platform"

# special case for syslog on Ubuntu
if [ "$service" = "syslog" ] && [ "$platform" = "Ubuntu" ]; then
    /etc/init.d/sysklogd force-reload
    if [ $? -eq 0 ]; then
        echo "Success"
        exit 0
    else
        echo "Failed force-reload with syslog init script on Ubuntu"
        echo "Trying to send SIGHUP instead"
    fi
fi

# get the pid
case $service in
    "syslog")
        if [ -z "$pidfile" ]; then
            case $platform in
                "Linux")
                    ReadPidFile "/var/run/syslogd.pid"
                    ;;
                "Solaris")
                    ReadPidFile "/etc/syslog.pid"
                    ;;
                "AIX")
                    ReadPidFile "/etc/syslog.pid"
                    ;;
                "HPUX")
                    ReadPidFile "/var/run/syslog.pid"
                    ;;
                "DARWIN")
                    ReadPidFile "/var/run/syslog.pid"
                    ;;
            esac
        else
            ReadPidFile "$pidfile"
        fi
        ;;
    "sshd-quest")
        if [ -z "$pidfile" ]; then
            if [ -f "/var/opt/quest/run/sshd.pid" ]; then
                ReadPidFile "/var/opt/quest/run/sshd.pid"
            else
                ReadPidFile "/var/run/sshd-quest.pid"
            fi
        else
            if [ -f "$pidfile" ]; then
                ReadPidFile "$pidfile"
            else
                ReadPidFile "/var/run/sshd-quest.pid"
            fi
        fi
        ;;
    "sshd")
        if [ -z "$pidfile" ]; then
            if [ -f "/var/run/sshd.pid" ]; then
                ReadPidFile "/var/run/sshd.pid"
            elif [ -f "/usr/local/etc/sshd.pid" ]; then
                ReadPidFile "/usr/local/etc/sshd.pid"
            elif [ -f "/etc/ssh/sshd.pid" ]; then
                ReadPidFile "/etc/ssh/sshd.pid"
            fi
        else
            ReadPidFile "$pidfile"
        fi
        ;;
    "vasd")
        if [ -z "$pidfile" ]; then
            if [ -f "/var/opt/quest/vas/vasd/.vasd.pid" ]; then
                ReadPidFile "/var/opt/quest/vas/vasd/.vasd.pid"
            else
                tmppidfile=`ps -eo command | grep "vasd -p" | grep -v grep | cut -d" " -f3 | sort -u`
                if [ ! -z "$tmppidfile" ]; then
                    DebugEcho "Found pid file from process list: $tmppidfile"
                    ReadPidFile "$tmppidfile"
                fi
            fi
        else
            ReadPidFile "$pidfile"
        fi
        ;;
    *)
        echo "You specified an unsupported service: $1"
        exit 1
        ;;
esac
if [ $? -eq 1 ]; then
    echo "Failed to read the service pid from the pid file"
    exit 1
fi
# signal the process
echo "Sending SIGHUP to $service, pid $pid"
SendSigHup $pid
if [ $? -eq 0 ]; then
    echo "Success"
    exit 0
else
    echo "Failed to send the SIGHUP"
    exit 1
fi
