#!/bin/sh

##==============================================================================
# Copyright 2022 One Identity LLC. ALL RIGHTS RESERVED.
##
## Version: 5.0.7.10004
##
##==============================================================================

CONFIG_PAM="/opt/quest/libexec/defender/config_pam"
UNCONFIGSCRIPT="/opt/quest/libexec/defender/configure_pam_defender.sh"

if [ "`id | sed 's/uid=\([0-9]*\).*/\1/'`" -ne 0 ] ; then
    echo "You must have root access to configure pam authentication\n"
    exit 1
fi

usage()
{
   echo "Usage: unconfigure_pam_defender.sh" 
   exit 1
}

if [ "x$1" != "x" ] ; then
   usage
fi

SERVICES=`$CONFIG_PAM services`

if [ $? != 0 ] ; then
    echo "Error getting pam service list: $SERVICES"
    exit 1
fi

for SERVICE in $SERVICES
do
    $UNCONFIGSCRIPT $SERVICE remove 2 > /dev/null
done
$CONFIG_PAM UNLINK -m pam_defender
